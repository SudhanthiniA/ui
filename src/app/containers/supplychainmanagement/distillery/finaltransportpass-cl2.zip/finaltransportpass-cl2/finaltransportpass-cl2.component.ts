import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-finaltransportpass-cl2',
  templateUrl: './finaltransportpass-cl2.component.html',
  styleUrls: ['./finaltransportpass-cl2.component.scss']
})
export class FinaltransportpassCl2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
