import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editimportpermit',
  templateUrl: './editimportpermit.component.html',
  styleUrls: ['./editimportpermit.component.scss']
})
export class EditimportpermitComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
