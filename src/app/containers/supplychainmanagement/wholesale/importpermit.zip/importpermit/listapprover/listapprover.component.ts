import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listapprover',
  templateUrl: './listapprover.component.html',
  styleUrls: ['./listapprover.component.scss']
})
export class ListapproverComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
