import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-importpermitsuccess',
  templateUrl: './importpermitsuccess.component.html',
  styleUrls: ['./importpermitsuccess.component.scss']
})
export class ImportpermitsuccessComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
