import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-retailbrandwiselist',
  templateUrl: './retailbrandwiselist.component.html',
  styleUrls: ['./retailbrandwiselist.component.scss']
})
export class RetailbrandwiselistComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
