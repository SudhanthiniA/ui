import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-retailbrandwiseofficerview',
  templateUrl: './retailbrandwiseofficerview.component.html',
  styleUrls: ['./retailbrandwiseofficerview.component.scss']
})
export class RetailbrandwiseofficerviewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
