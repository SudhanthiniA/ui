import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-exceptionliftingprocess',
  templateUrl: './exceptionliftingprocess.component.html',
  styleUrls: ['./exceptionliftingprocess.component.scss']
})
export class ExceptionliftingprocessComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
